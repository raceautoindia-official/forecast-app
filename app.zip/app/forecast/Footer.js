// File: app/components/Footer.jsx
'use client';
import React from 'react';

export default function Footer() {
  return (
    <footer className="app-footer">
      {/* <span className="source">Source: N/A</span> */}
      <span className="copyright">© Copyright 2025 Race Auto India – All Rights Reserved.</span>
      <nav className="links">
        <a href="/terms" className="footer-link">Terms & Conditions {'    '} </a>
        <a href="/privacy" className="footer-link">Privacy Policy</a>
      </nav>

      <style jsx>{`
        .app-footer {
          margin-top: 40px;
          padding: 20px 0;
          border-top: 1px solid rgba(255,255,255,0.2);
          display: flex;
          justify-content: center;
          align-items: center;
          gap: 24px;
          color: rgba(255,255,255,0.7);
          font-size: 0.875rem;
        }
        .footer-link {
          color: rgba(255,255,255,0.7);
          text-decoration: none;
          transition: color 200ms ease;
        }
        .footer-link:hover {
          color: #FFC107;
        }
      `}</style>
    </footer>
  );
}
