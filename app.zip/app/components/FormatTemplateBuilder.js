// File: app/components/FormatTemplateBuilder.js
'use client';
import { useState, useEffect } from 'react';
import { Button, Select, message } from 'antd';
import { DownloadOutlined } from '@ant-design/icons';

export default function FormatTemplateBuilder() {
  const [formatCharts, setFormatCharts] = useState([]);
  const [rowChart, setRowChart] = useState(null);
  const [rowLevels, setRowLevels] = useState([]);
  const [selectedRowLevel, setSelectedRowLevel] = useState(null);

  const [colChart, setColChart] = useState(null);
  const [colLevels, setColLevels] = useState([]);
  const [selectedColLevel, setSelectedColLevel] = useState(null);

  useEffect(() => {
    fetch('/api/formatHierarchy')
      .then((res) => res.json())
      .then((data) => setFormatCharts(data));
  }, []);

  const fetchLevels = async (chartId, type) => {
    const res = await fetch(`/api/formatHierarchyLevels?chartId=${chartId}`);
    const data = await res.json();
    if (type === 'row') setRowLevels(data);
    else setColLevels(data);
  };

  const handleRowChartSelect = (id) => {
    setRowChart(id);
    setSelectedRowLevel(null);
    fetchLevels(id, 'row');
  };

  const handleColChartSelect = (id) => {
    setColChart(id);
    setSelectedColLevel(null);
    fetchLevels(id, 'col');
  };

  const handleDownload = async () => {
    if (!rowChart || !selectedRowLevel || !colChart || !selectedColLevel) {
      return message.warning('Please select both row and column charts and levels');
    }

    const res = await fetch('/api/generateExcelTemplate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        rowChartId: rowChart,
        rowLevelId: selectedRowLevel,
        colChartId: colChart,
        colLevelId: selectedColLevel,
      }),
    });

    if (!res.ok) {
      return message.error('Failed to generate template');
    }

    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'volume_template.xlsx';
    document.body.appendChild(link);
    link.click();
    link.remove();
  };

  return (
    <div style={{ padding: 16 }}>
      <h3>Create Excel Format</h3>

      <div style={{ marginBottom: 12 }}>
        <strong>Row Flow Chart:</strong>
        <Select
          placeholder="Select Row Chart"
          value={rowChart}
          onChange={handleRowChartSelect}
          options={formatCharts.map(c => ({ label: c.name, value: c.id }))}
          style={{ width: 250, marginLeft: 8 }}
        />

        {rowLevels.length > 0 && (
          <Select
            placeholder="Select Row Level"
            value={selectedRowLevel}
            onChange={setSelectedRowLevel}
            options={rowLevels.map(l => ({ label: l.name, value: l.id }))}
            style={{ width: 250, marginLeft: 16 }}
          />
        )}
      </div>

      <div style={{ marginBottom: 12 }}>
        <strong>Column Flow Chart:</strong>
        <Select
          placeholder="Select Column Chart"
          value={colChart}
          onChange={handleColChartSelect}
          options={formatCharts.map(c => ({ label: c.name, value: c.id }))}
          style={{ width: 250, marginLeft: 8 }}
        />

        {colLevels.length > 0 && (
          <Select
            placeholder="Select Column Level"
            value={selectedColLevel}
            onChange={setSelectedColLevel}
            options={colLevels.map(l => ({ label: l.name, value: l.id }))}
            style={{ width: 250, marginLeft: 16 }}
          />
        )}
      </div>

      <Button
        type="primary"
        icon={<DownloadOutlined />}
        onClick={handleDownload}
        style={{ marginTop: 16 }}
      >
        Download Excel Template
      </Button>
    </div>
  );
}
