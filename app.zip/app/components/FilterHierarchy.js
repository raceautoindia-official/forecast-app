'use client';
import { useState, useEffect } from 'react';
import { Button, Form, Input, List } from 'antd';
import { DeleteOutlined } from '@ant-design/icons';

export default function FilterHierarchy() {
  const [filterHierarchy, setFilterHierarchy] = useState([]);

  const fetchFilterHierarchy = async () => {
    const res = await fetch('/api/filterHierarchy');
    const data = await res.json();
    setFilterHierarchy(data);
  };

  useEffect(() => {
    fetchFilterHierarchy();
  }, []);

  const addFilterNode = async (values) => {
    const res = await fetch('/api/filterHierarchy', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(values),
    });
    if (res.ok) {
      fetchFilterHierarchy();
    }
  };

  const deleteFilterNode = async (id) => {
    const res = await fetch('/api/filterHierarchy', {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id }),
    });
    if (res.ok) {
      fetchFilterHierarchy();
    }
  };

  const onFinish = (values) => {
    addFilterNode(values);
  };

  return (
    <>
      <Form layout="inline" onFinish={onFinish} style={{ marginBottom: '1rem' }}>
        <Form.Item
          name="field_name"
          rules={[{ required: true, message: 'Field required' }]}
        >
          <Input placeholder="Field Name" />
        </Form.Item>
        <Form.Item
          name="field_value"
          rules={[{ required: true, message: 'Value required' }]}
        >
          <Input placeholder="Field Value" />
        </Form.Item>
        <Form.Item>
          <Button type="primary" htmlType="submit">
            Add Filter Node
          </Button>
        </Form.Item>
      </Form>
      <List
        header={<div>Filter Hierarchy</div>}
        bordered
        dataSource={filterHierarchy}
        renderItem={(node) => (
          <List.Item
            key={node.id}
            actions={[
              <Button
                type="link"
                icon={<DeleteOutlined />}
                onClick={() => deleteFilterNode(node.id)}
                key="delete"
              >
                Delete
              </Button>,
            ]}
          >
            {node.field_name}: {node.field_value} (ID: {node.id}){' '}
            {node.parent_id && `(Parent: ${node.parent_id})`}
          </List.Item>
        )}
      />
    </>
  );
}
