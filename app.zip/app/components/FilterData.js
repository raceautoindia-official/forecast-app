'use client';
import { useState, useEffect } from 'react';
import { Table, Select, message } from 'antd';

export default function FilterData() {
  const [filters, setFilters] = useState([]);
  const [selectedFilter, setSelectedFilter] = useState(null);
  const [volumeData, setVolumeData] = useState([]);

  const fetchFilters = async () => {
    const res = await fetch('/api/contentHierarchy');
    const data = await res.json();
    setFilters(data);
  };

  useEffect(() => {
    fetchFilters();
  }, []);

  const onFilterChange = async (value) => {
    setSelectedFilter(value);
    // Example API call to fetch volume data based on filter; adjust the API as needed.
    const res = await fetch(`/api/filterVolumeData?filterId=${value}`);
    if (res.ok) {
      const data = await res.json();
      setVolumeData(data);
    } else {
      message.error('Error fetching volume data');
    }
  };

  return (
    <>
      <Select placeholder="Select a filter category" style={{ width: 300, marginBottom: 16 }} onChange={onFilterChange}>
        {filters.map(filter => (
          <Select.Option key={filter.id} value={filter.id}>
            {filter.name}
          </Select.Option>
        ))}
      </Select>
      <Table
        dataSource={volumeData}
        columns={[
          { title: 'ID', dataIndex: 'id' },
          { title: 'Stream', dataIndex: 'stream' },
          { title: 'Data', dataIndex: 'data', render: (data) => JSON.stringify(data) },
          { title: 'Created At', dataIndex: 'created_at' }
        ]}
        rowKey="id"
      />
    </>
  );
}
