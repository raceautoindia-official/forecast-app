// File: app/components/UploadVolumeData.js
'use client';
import { useState, useEffect } from 'react';
import { Button, Select, Upload, message } from 'antd';
import { UploadOutlined } from '@ant-design/icons';

export default function UploadVolumeData() {
  const [formatCharts, setFormatCharts] = useState([]);
  const [hierarchyNodes, setHierarchyNodes] = useState([]);

  const [rowChart, setRowChart] = useState(null);
  const [rowLevels, setRowLevels] = useState([]);
  const [selectedRowLevel, setSelectedRowLevel] = useState(null);

  const [colChart, setColChart] = useState(null);
  const [colLevels, setColLevels] = useState([]);
  const [selectedColLevel, setSelectedColLevel] = useState(null);

  const [fileList, setFileList] = useState([]);

  useEffect(() => {
    fetch('/api/formatHierarchy')
      .then((res) => res.json())
      .then((data) => {
        setHierarchyNodes(data);
        const rootCharts = data.filter(node => node.parent_id === null);
        setFormatCharts(rootCharts);
      });
  }, []);

  const getLevelOptions = (chartId) => {
    const nodeMap = new Map();
    const levelMap = new Map();

    hierarchyNodes.forEach((node) => {
      if (node.chart_id === chartId) {
        nodeMap.set(node.id, node);
      }
    });

    nodeMap.forEach((node) => {
      let level = 0;
      let current = node;
      while (current.parent_id && nodeMap.has(current.parent_id)) {
        level++;
        current = nodeMap.get(current.parent_id);
      }
      if (!levelMap.has(level)) levelMap.set(level, []);
      levelMap.get(level).push(node);
    });

    const levelOptions = [...levelMap.entries()].map(([level, nodes]) => ({
      label: `Level ${level + 1}`,
      value: nodes.map(n => n.id).join(',')
    }));

    return levelOptions;
  };

  const handleRowChartSelect = (id) => {
    setRowChart(id);
    setSelectedRowLevel(null);
    const levels = getLevelOptions(id);
    setRowLevels(levels);
  };

  const handleColChartSelect = (id) => {
    setColChart(id);
    setSelectedColLevel(null);
    const levels = getLevelOptions(id);
    setColLevels(levels);
  };

  const handleUpload = async () => {
    if (!fileList.length || !rowChart || !selectedRowLevel || !colChart || !selectedColLevel) {
      return message.error('Please complete all selections and choose a file.');
    }

    const formData = new FormData();
    formData.append('file', fileList[0]);
    formData.append('rowChartId', rowChart);
    formData.append('rowLevelId', selectedRowLevel);
    formData.append('colChartId', colChart);
    formData.append('colLevelId', selectedColLevel);

    const res = await fetch('/api/uploadVolumeData', {
      method: 'POST',
      body: formData,
    });

    if (res.ok) {
      message.success('Upload successful!');
      setFileList([]);
    } else {
      const error = await res.json();
      message.error(error.message || 'Upload failed');
    }
  };

  return (
    <div style={{ padding: 16 }}>
      <h3>Upload Volume Data with Format Validation</h3>

      <div style={{ marginBottom: 16 }}>
        <strong>Row Flow Chart:</strong>
        <Select
          placeholder="Select Row Chart"
          value={rowChart}
          onChange={handleRowChartSelect}
          options={formatCharts.map(c => ({ label: c.name, value: c.id }))}
          style={{ width: 250, marginLeft: 8 }}
        />

        {rowLevels.length > 0 && (
          <Select
            placeholder="Select Row Level"
            value={selectedRowLevel}
            onChange={setSelectedRowLevel}
            options={rowLevels}
            style={{ width: 400, marginLeft: 16 }}
          />
        )}
      </div>

      <div style={{ marginBottom: 16 }}>
        <strong>Column Flow Chart:</strong>
        <Select
          placeholder="Select Column Chart"
          value={colChart}
          onChange={handleColChartSelect}
          options={formatCharts.map(c => ({ label: c.name, value: c.id }))}
          style={{ width: 250, marginLeft: 8 }}
        />

        {colLevels.length > 0 && (
          <Select
            placeholder="Select Column Level"
            value={selectedColLevel}
            onChange={setSelectedColLevel}
            options={colLevels}
            style={{ width: 400, marginLeft: 16 }}
          />
        )}
      </div>

      <Upload
        beforeUpload={(file) => {
          setFileList([file]);
          return false;
        }}
        fileList={fileList}
        onRemove={() => setFileList([])}
      >
        <Button icon={<UploadOutlined />}>Select Excel File</Button>
      </Upload>

      <Button
        type="primary"
        onClick={handleUpload}
        style={{ marginTop: 16 }}
      >
        Upload Volume Data
      </Button>
    </div>
  );
}







