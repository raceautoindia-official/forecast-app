'use client';
import { useState, useEffect } from 'react';
import { Button, Form, Input, List } from 'antd';
import { DeleteOutlined } from '@ant-design/icons';

export default function ContentHierarchy() {
  const [hierarchy, setHierarchy] = useState([]);
  const [newNodeName, setNewNodeName] = useState('');
  const [parentId, setParentId] = useState('');

  const fetchHierarchy = async () => {
    const res = await fetch('/api/hierarchy');
    const data = await res.json();
    setHierarchy(data);
  };

  useEffect(() => {
    fetchHierarchy();
  }, []);

  const addNode = async () => {
    const res = await fetch('/api/hierarchy', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ parent_id: parentId || null, name: newNodeName }),
    });
    if (res.ok) {
      setNewNodeName('');
      setParentId('');
      fetchHierarchy();
    }
  };

  const deleteNode = async (id) => {
    const res = await fetch('/api/hierarchy', {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id }),
    });
    if (res.ok) {
      fetchHierarchy();
    }
  };

  return (
    <>
      <Form layout="inline" style={{ marginBottom: '1rem' }}>
        <Form.Item>
          <Input
            placeholder="Node name"
            value={newNodeName}
            onChange={(e) => setNewNodeName(e.target.value)}
          />
        </Form.Item>
        <Form.Item>
          <Input
            placeholder="Parent ID (optional)"
            value={parentId}
            onChange={(e) => setParentId(e.target.value)}
          />
        </Form.Item>
        <Form.Item>
          <Button type="primary" onClick={addNode}>
            Add Node
          </Button>
        </Form.Item>
      </Form>
      <List
        header={<div>Hierarchy Nodes</div>}
        bordered
        dataSource={hierarchy}
        renderItem={(node) => (
          <List.Item
            key={node.id}
            actions={[
              <Button
                type="link"
                icon={<DeleteOutlined />}
                onClick={() => deleteNode(node.id)}
                key="delete"
              >
                Delete
              </Button>,
            ]}
          >
            {node.name} (ID: {node.id}) {node.parent_id && `(Parent: ${node.parent_id})`}
          </List.Item>
        )}
      />
    </>
  );
}
