'use client';
import { Tabs } from 'antd';
import ContentHierarchyFlow from './components/ContentHierarchyFlow';
import FormatHierarchyFlow from './components/FormatHierarchyFlow';
import FilterData from './components/FilterData';
import UploadVolumeData from './components/UploadVolumeData';

export default function Home() {
  const tabItems = [
    { key: '1', label: 'Content Hierarchy', children: <ContentHierarchyFlow /> },
    { key: '2', label: 'Format Hierarchy', children: <FormatHierarchyFlow /> },
    { key: '3', label: 'Filter Data', children: <FilterData /> },
    { key: '4', label: 'Upload Volume Data', children: <UploadVolumeData /> }
  ];

  return (
    <div style={{ padding: '2rem' }}>
      <h1>Forecast Application CMS</h1>
      <Tabs defaultActiveKey="1" items={tabItems} />
    </div>
  );
}



