// app/api/hierarchy/route.js
import pool from '@/lib/db';

export async function GET() {
  try {
    const [rows] = await pool.query('SELECT * FROM hierarchy_nodes');
    return new Response(JSON.stringify(rows), { status: 200 });
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500 }
    );
  }
}

export async function POST(req) {
  try {
    const { parent_id, name } = await req.json();
    const [result] = await pool.query(
      'INSERT INTO hierarchy_nodes (parent_id, name) VALUES (?, ?)',
      [parent_id || null, name]
    );
    return new Response(
      JSON.stringify({ id: result.insertId, parent_id, name }),
      { status: 201 }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500 }
    );
  }
}

export async function DELETE(req) {
  try {
    const { id } = await req.json();
    await pool.query('DELETE FROM hierarchy_nodes WHERE id = ?', [id]);
    return new Response(
      JSON.stringify({ message: 'Node deleted' }),
      { status: 200 }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500 }
    );
  }
}


