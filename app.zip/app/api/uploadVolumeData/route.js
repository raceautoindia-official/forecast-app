// File: app/api/uploadVolumeData/route.js
import * as XLSX from 'xlsx';
import pool from '../../../lib/db';
import formidable from 'formidable';

export const config = {
  api: {
    bodyParser: false,
  },
};

export async function POST(req) {
  const form = formidable({ multiples: false });

  const parseForm = (req) =>
    new Promise((resolve, reject) => {
      form.parse(req, (err, fields, files) => {
        if (err) reject(err);
        else resolve({ fields, files });
      });
    });

  try {
    const { fields, files } = await parseForm(req);
    const { rowChartId, rowLevelId, colChartId, colLevelId } = fields;
    const file = files.file;

    if (!file || !rowChartId || !rowLevelId || !colChartId || !colLevelId) {
      return new Response(JSON.stringify({ error: 'Missing fields' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    const workbook = XLSX.readFile(file.filepath);
    const sheet = workbook.Sheets[workbook.SheetNames[0]];
    const jsonData = XLSX.utils.sheet_to_json(sheet, { header: 1 });

    // Get expected row and column headers from DB
    const [rowNodes] = await pool.query(
      'SELECT name FROM format_hierarchy WHERE parent_id = ? AND chart_id = ?',
      [rowLevelId, rowChartId]
    );
    const [colNodes] = await pool.query(
      'SELECT name FROM format_hierarchy WHERE parent_id = ? AND chart_id = ?',
      [colLevelId, colChartId]
    );

    const expectedRowLabels = rowNodes.map(n => n.name);
    const expectedColLabels = colNodes.map(n => n.name);

    // Validate headers
    const actualHeaderRow = jsonData[0]?.slice(1) || [];
    const actualRowLabels = jsonData.slice(1).map(row => row[0]);

    const headersMatch =
      expectedColLabels.length === actualHeaderRow.length &&
      expectedColLabels.every((val, idx) => val === actualHeaderRow[idx]);

    const rowsMatch =
      expectedRowLabels.length === actualRowLabels.length &&
      expectedRowLabels.every((val, idx) => val === actualRowLabels[idx]);

    if (!headersMatch || !rowsMatch) {
      return new Response(JSON.stringify({ error: 'Excel format does not match the selected row/column structure.' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    // Save valid data
    await pool.query(
      'INSERT INTO volume_data (row_chart_id, col_chart_id, row_level_id, col_level_id, data) VALUES (?, ?, ?, ?, ?)',
      [rowChartId, colChartId, rowLevelId, colLevelId, JSON.stringify(jsonData)]
    );

    return new Response(JSON.stringify({ message: 'Data uploaded successfully' }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
    });

  } catch (err) {
    console.error(err);
    return new Response(JSON.stringify({ error: err.message }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }
}


