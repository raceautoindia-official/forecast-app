// app/api/filterHierarchy/route.js
import pool from '@/lib/db';

export async function GET() {
  try {
    const [rows] = await pool.query('SELECT * FROM filter_hierarchy');
    return new Response(JSON.stringify(rows), { status: 200 });
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500 }
    );
  }
}

export async function POST(req) {
  try {
    const { parent_id, field_name, field_value } = await req.json();
    const [result] = await pool.query(
      'INSERT INTO filter_hierarchy (parent_id, field_name, field_value) VALUES (?, ?, ?)',
      [parent_id || null, field_name, field_value]
    );
    return new Response(
      JSON.stringify({ id: result.insertId, parent_id, field_name, field_value }),
      { status: 201 }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500 }
    );
  }
}

export async function DELETE(req) {
  try {
    const { id } = await req.json();
    await pool.query('DELETE FROM filter_hierarchy WHERE id = ?', [id]);
    return new Response(
      JSON.stringify({ message: 'Filter node deleted' }),
      { status: 200 }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500 }
    );
  }
}
