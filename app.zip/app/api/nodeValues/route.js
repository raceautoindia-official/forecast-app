// app/api/nodeValues/route.js
import pool from '@/lib/db';

export async function GET(req) {
  try {
    const { searchParams } = new URL(req.url);
    const node_id = searchParams.get('node_id');
    const [rows] = await pool.query('SELECT * FROM node_values WHERE node_id = ?', [node_id]);
    return new Response(JSON.stringify(rows), { status: 200 });
  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), { status: 500 });
  }
}

export async function POST(req) {
  try {
    const { node_id, value } = await req.json();
    const [result] = await pool.query(
      'INSERT INTO node_values (node_id, value) VALUES (?, ?)',
      [node_id, value]
    );
    return new Response(JSON.stringify({ id: result.insertId, node_id, value }), { status: 201 });
  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), { status: 500 });
  }
}

export async function DELETE(req) {
  try {
    const { id } = await req.json();
    await pool.query('DELETE FROM node_values WHERE id = ?', [id]);
    return new Response(JSON.stringify({ message: 'Value deleted' }), { status: 200 });
  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), { status: 500 });
  }
}
