// File: app/api/volumeData/route.js (App Router API)
import * as XLSX from 'xlsx';
import formidable from 'formidable';
import pool from '../../../lib/db';

export const config = {
  api: {
    bodyParser: false,
  },
};

export async function POST(req) {
  const form = formidable({ multiples: false });

  const parseForm = (req) =>
    new Promise((resolve, reject) => {
      form.parse(req, (err, fields, files) => {
        if (err) reject(err);
        else resolve({ fields, files });
      });
    });

  try {
    const { fields, files } = await parseForm(req);
    const stream = fields.stream;
    const format_chart_id = fields.format_chart_id;
    const file = files.file;

    if (!file || !stream || !format_chart_id) {
      return new Response(JSON.stringify({ error: 'Missing required fields' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    const workbook = XLSX.readFile(file.filepath);
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    const jsonData = XLSX.utils.sheet_to_json(worksheet);

    await pool.query(
      'INSERT INTO volume_data (stream, format_chart_id, data) VALUES (?, ?, ?)',
      [stream, format_chart_id, JSON.stringify(jsonData)]
    );

    return new Response(JSON.stringify({ message: 'Volume data uploaded successfully' }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }
}

// FRONTEND SNIPPET EXAMPLE FOR UploadVolumeData.js

'use client';
import { useEffect, useState } from 'react';
import { Button, Select, Upload, message } from 'antd';
import { UploadOutlined } from '@ant-design/icons';

export default function UploadVolumeData() {
  const [hierarchy, setHierarchy] = useState([]);
  const [pathSelections, setPathSelections] = useState([]);
  const [formatCharts, setFormatCharts] = useState([]);
  const [selectedChart, setSelectedChart] = useState(null);
  const [fileList, setFileList] = useState([]);

  useEffect(() => {
    const fetchHierarchy = () => {
      fetch('/api/contentHierarchy')
        .then((res) => res.json())
        .then((data) => setHierarchy(data));
    };

    fetchHierarchy();

    const handleUpdate = () => {
      fetchHierarchy();
      setPathSelections([]); // Optional: reset selection
    };

    window.addEventListener('content-hierarchy-updated', handleUpdate);
    return () => {
      window.removeEventListener('content-hierarchy-updated', handleUpdate);
    };
  }, []);

  useEffect(() => {
    fetch('/api/formatHierarchy')
      .then((res) => res.json())
      .then((data) => setFormatCharts(data));
  }, []);

  const getChildren = (parentId) => hierarchy.filter((n) => n.parent_id === parentId);

  const getStreamPath = () =>
    pathSelections
      .map((id) => hierarchy.find((n) => n.id === id)?.name)
      .filter(Boolean)
      .join(' > ');

  const handleLevelChange = (value, level) => {
    const newSelections = [...pathSelections.slice(0, level), value];
    setPathSelections(newSelections);
  };

  const handleUpload = async () => {
    const stream = getStreamPath();
    if (!stream || !selectedChart || fileList.length === 0) {
      message.error('Please select stream, format chart, and file.');
      return;
    }

    const formData = new FormData();
    formData.append('file', fileList[0]);
    formData.append('stream', stream);
    formData.append('format_chart_id', selectedChart);

    const res = await fetch('/api/volumeData', {
      method: 'POST',
      body: formData,
    });

    if (res.ok) {
      message.success('Upload successful!');
      setFileList([]);
    } else {
      const error = await res.json();
      message.error(error.message || 'Upload failed');
    }
  };

  return (
    <div style={{ padding: 16 }}>
      <div style={{ marginBottom: 16 }}>
        <strong>Select Stream (Content Hierarchy):</strong>
        {[...Array(pathSelections.length + 1)].map((_, level) => {
          const parentId = pathSelections[level - 1] || null;
          const options = getChildren(parentId);
          if (options.length === 0) return null;
          return (
            <Select
              key={level}
              placeholder={`Level ${level + 1}`}
              onChange={(value) => handleLevelChange(value, level)}
              value={pathSelections[level]}
              options={options.map((node) => ({
                label: node.name,
                value: node.id,
              }))}
              style={{ width: 200, marginRight: 8, marginTop: 8 }}
            />
          );
        })}
      </div>

      <div style={{ marginBottom: 16 }}>
        <strong>Selected Stream:</strong> {getStreamPath() || 'None'}
      </div>

      <Select
        placeholder="Select Format Chart"
        value={selectedChart}
        onChange={setSelectedChart}
        options={formatCharts.map((c) => ({ label: c.name, value: c.id }))}
        style={{ width: 300, marginBottom: 16 }}
      />

      <Upload
        beforeUpload={(file) => {
          setFileList([file]);
          return false;
        }}
        fileList={fileList}
        onRemove={() => setFileList([])}
      >
        <Button icon={<UploadOutlined />}>Select Excel File</Button>
      </Upload>

      <Button type="primary" onClick={handleUpload} style={{ marginTop: 16 }}>
        Upload Volume Data
      </Button>
    </div>
  );
}

