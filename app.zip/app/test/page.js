"use client"
import React from 'react';
import { Button, Modal } from 'antd';
import { ExclamationCircleOutlined } from '@ant-design/icons';

const TestConfirm = () => {
  const showDeleteConfirm = () => {
    Modal.confirm({
      title: 'Are you sure?',
      icon: <ExclamationCircleOutlined />,
      content: 'This is a test confirmation modal.',
      zIndex: 3000,
      onOk() {
        console.log('Confirmed!');
      },
    });
  };

  return <Button onClick={showDeleteConfirm}>Test Confirm Modal</Button>;
};

export default TestConfirm;
