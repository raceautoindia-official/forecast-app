// File: app/components/Footer.jsx
'use client';
import React from 'react';
import Link from 'next/link';
import { FaEnvelope } from 'react-icons/fa';

export default function Footer() {
  return (
    <footer className="app-footer">
      <span className="copyright">
        © Copyright 2025 Race Auto India – All Rights Reserved.
      </span>
      <nav className="links">
        <Link href="/terms" legacyBehavior>
          <a className="footer-link">Terms & Conditions</a>
        </Link>
        <span className="separator">•</span>
        <Link href="/privacy" legacyBehavior>
          <a className="footer-link">Privacy Policy</a>
        </Link>
        <span className="separator">•</span>
        <Link href="/contact" legacyBehavior>
          <a className="footer-link">
           Contact Us
          </a>
        </Link>
      </nav>

      <style jsx>{`
        .app-footer {
          margin-top: var(--space-md, 32px);
          padding: var(--space-md, 16px) 0;
          border-top: 1px solid rgba(255,255,255,0.2);
          display: flex;
          justify-content: center;
          align-items: center;
          gap: var(--space-md, 24px);
          color: rgba(255,255,255,0.7);
          font-size: 0.875rem;
          background: var(--bg);
        }
        .links {
          display: flex;
          align-items: center;
          gap: var(--space-sm, 8px);
        }
        .separator {
          color: rgba(255,255,255,0.5);
        }
        .footer-link {
          color: rgba(255,255,255,0.7);
          text-decoration: none;
          display: inline-flex;
          align-items: center;
          gap: var(--space-xs, 4px);
          transition: color 200ms ease, transform 200ms ease;
        }
        .footer-link:hover {
          color: var(--accent);
          transform: translateY(-1px);
        }
        .footer-icon {
          font-size: 0.9rem;
        }
      `}</style>
    </footer>
  );
}
