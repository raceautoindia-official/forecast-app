// File: app/forecast/page.js
'use client';
import React, { useState, useEffect, useMemo } from "react";
import Image from "next/image";
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  ResponsiveContainer,
  Tooltip,
  Legend,
  PieChart,
  Pie,
  Cell,
  CartesianGrid,
  Brush,
  Rectangle
} from 'recharts';
import { motion, AnimatePresence } from 'framer-motion';
import { FaClipboardList, FaBolt } from 'react-icons/fa';
import './forecast.css';
import Footer from './Footer';
// Hook for linear regression forecast
import { useLinearRegressionForecast } from "../hooks/LinearRegressionForecast";
// Hook for score based forecast
import { useForecastGrowth }       from "../hooks/useForecastGrowth";
import { useAverageYearlyScores }  from "../hooks/useAverageYearlyScores";

export default function ForecastPage() {

  const router = useRouter()

  // --- UI state ---
  const [isSidebarOpen, setIsSidebarOpen]             = useState(true);
  const [isGraphListOpen, setIsGraphListOpen]         = useState(true);
  const [isDatasetFilterOpen, setIsDatasetFilterOpen] = useState(true);
  const [isRegionFilterOpen, setIsRegionFilterOpen]   = useState(true);

  // --- fetched data ---
  const [graphs, setGraphs]               = useState([]);
  const [volumeDataMap, setVolumeDataMap] = useState({});
  const [hierarchyMap, setHierarchyMap]   = useState({});
  const [scoreSettings, setScoreSettings] = useState({ yearNames: [] });
  const [submissions, setSubmissions] = useState([]);
  const [formatHierarchy, setFormatHierarchy] = useState([]);

  // --- user selections ---
  const [selectedGraphId, setSelectedGraphId]     = useState(null);
  const [selectedDatasetId, setSelectedDatasetId] = useState(null);
  const [selectedRegions, setSelectedRegions]     = useState([]);

  // 1) Fetch all needed data once
  useEffect(() => {
    fetch('/api/graphs')
      .then(r => r.json())
      .then(setGraphs)
      .catch(console.error);

    fetch('/api/volumeData')
      .then(r => r.json())
      .then(arr => {
        const m = {};
        arr.forEach(d => {
          // filter out any weird “undefined” key
          const cleanData = Object.fromEntries(
            Object.entries(d.data).filter(([k,v]) => k != null && Object.keys(v).length)
          );
          m[d.id] = { ...d, data: cleanData };
        });
        setVolumeDataMap(m);
      })
      .catch(console.error);


    fetch('/api/contentHierarchy')
      .then(r => r.json())
      .then(arr => {
        const m = {};
        arr.forEach(node => { m[node.id] = node.name; });
        setHierarchyMap(m);
      })
      .catch(console.error);

    fetch('/api/scoreSettings')
      .then(r => r.json())
      .then(data => setScoreSettings(data))
      .catch(console.error);
    
    // now also fetch the format‐hierarchy tree
    fetch('/api/formatHierarchy')
    .then(r => r.json())
    .then(setFormatHierarchy)
    .catch(console.error);

    // also pull in the submissions, questions & settings so we can compute averages
    Promise.all([
        fetch('/api/saveScores'),
        fetch('/api/questions'),
        fetch('/api/scoreSettings')
      ])
      .then(async ([subRes, qRes, sRes]) => {
        if (!subRes.ok || !qRes.ok || !sRes.ok) throw new Error();
      const { submissions: rawSubs } = await subRes.json();
        const questions = await qRes.json();
        const { yearNames } = await sRes.json();
  
      // build posAttrs, negAttrs & weights (same as in UserOverallScores)
        const posAttrs = [], negAttrs = [], weights = {};
      questions.forEach(q => {
          const key = String(q.id);
          weights[key] = Number(q.weight) || 0;
          const attr = { key, label: q.text };
          q.type === 'positive' ? posAttrs.push(attr) : negAttrs.push(attr);
        });
  
        // enrich
        const enriched = rawSubs.map(sub => {
          const posScores = {}, negScores = {};
          posAttrs.forEach(a => posScores[a.key] = Array(yearNames.length).fill(0));
          negAttrs.forEach(a => negScores[a.key] = Array(yearNames.length).fill(0));
        sub.scores.forEach(({ questionId, yearIndex, score, skipped }) => {
            if (skipped) return;
            const k = String(questionId);
            if (posScores[k]) posScores[k][yearIndex] = score;
            if (negScores[k]) negScores[k][yearIndex] = score;
          });
          return{
            id:            sub.id,
            createdAt:     sub.createdAt,
            posAttributes: posAttrs, negAttributes: negAttrs,
            posScores,     negScores,
            weights,
            yearNames
          };
        });
  
        setSubmissions(enriched);
        setLoading(false);
      })
      .catch(console.error);
  }, []);

  // 2) Default dataset when graph changes
  useEffect(() => {
    const g = graphs.find(g => g.id === selectedGraphId);
    if (g && g.dataset_ids.length) {
      setSelectedDatasetId(g.dataset_ids[0]);
    }
  }, [selectedGraphId, graphs]);

  // 3) Default select all regions when dataset changes
  const selectedDataset = volumeDataMap[selectedDatasetId];
  useEffect(() => {
    if (selectedDataset?.data) {
      setSelectedRegions(Object.keys(selectedDataset.data));
    }
  }, [selectedDataset]);

  const selectedGraph = graphs.find(g => g.id === selectedGraphId);

  // Derive allRegions from selectedDataset
  const allRegions = useMemo(
    () => selectedDataset?.data ? Object.keys(selectedDataset.data) : [],
    [selectedDataset]
  );

  // 4) Chart data for historical
  const chartData = useMemo(() => {
    if (!selectedDataset?.data || !selectedRegions.length) return [];
    const data = selectedDataset.data;
    console.log("data ", data);
    const regions = selectedRegions.filter(r => data[r]);
    console.log("regions " ,regions);
    if (!regions.length) return [];
    const years = Object.keys(data[regions[0]]).sort();
    return years.map(year => {
      const row = { year };
      regions.forEach(r => row[r] = data[r][year] ?? 0);
      return row;
    });
  }, [selectedDataset, selectedRegions]);

  // 5) Pie data
  const pieData = useMemo(() => {
    if (!selectedDataset?.data) return [];
    const data = selectedDataset.data;
    return allRegions
      .filter(r => selectedRegions.includes(r))
      .map(r => ({
        name:  r,
        value: Object.values(data[r] || {}).reduce((s, v) => s + v, 0)
      }));
  }, [selectedDataset, selectedRegions, allRegions]);

  // 6) Aggregate historical volumes
  const historicalVolumes = useMemo(() => {
    return chartData.map(row =>
      allRegions.reduce((sum, r) => sum + (row[r] || 0), 0)
    );
  }, [chartData, allRegions]);
  // **NEW**: compute your per-year average scores from all submissions
  // (you already fetched submissions via setSubmissions in your effect)
  const { yearNames: scoreYearNames, averages: avgScores } = useAverageYearlyScores(submissions);
  // turn [{year,avg},…] into [1.43, 0.52, …]
  const avgScoreValues = avgScores.map(a => Number(a.avg));

  // 7) Linear regression forecast hook
  const forecastDataLR = useLinearRegressionForecast(
    historicalVolumes,
    scoreSettings.yearNames || []
  );

  // 8) Score-based forecast hook
  const forecastDataScore = useForecastGrowth(
    historicalVolumes,
    avgScoreValues,
  );

    // 9) Combine historical + forecast, merging the boundary into the last historical point
    const combinedData = useMemo(() => {
    if (!chartData.length) return [];

    // 1) Build historical slice, with forecastVolume initialized to null
    const hist = historicalVolumes.map((v, i) => ({
      year:           Number(chartData[i].year),
      value:          v,
      forecastVolume: null
    }));

    // 2) Inject the last historical value into forecastVolume of the last hist point
    if (hist.length > 0) {
      hist[hist.length - 1].forecastVolume = hist[hist.length - 1].value;
    }

    // 3) Build your forecast slice (value stays null), starting at the next year
    const fc = (forecastDataLR || []).map((pt, i) => ({
      year:           Number(scoreSettings.yearNames[i]),  // e.g. 2024, 2025…
      value:          null,
      forecastVolume: pt.forecastVolume
    }));

    // 4) Simply concat – years will already be in ascending order
    return [...hist, ...fc];
  }, [historicalVolumes, forecastDataLR, chartData, scoreSettings.yearNames]);

  // 10) Combine historical + score-based forecast
  const combinedDataScore = useMemo(() => {
    if (!chartData.length) return [];
    const hist = historicalVolumes.map((v,i) => ({
      year: Number(chartData[i].year),
      value: v,
      forecastVolume: null
    }));
    if (hist.length) hist[hist.length-1].forecastVolume = hist[hist.length-1].value;
    console.log("forecastDataScore",forecastDataScore);
    const fc = forecastDataScore.map((pt,i) => ({
      year: Number(scoreYearNames[i]),
      value: null,
      forecastVolume: pt.forecastVolume
    }));
    return [...hist, ...fc];
  }, [chartData, historicalVolumes, forecastDataScore, scoreYearNames]);

  const bothData = useMemo(() => {
    if (!chartData.length) return [];
    // 1) historical…
    const hist = historicalVolumes.map((v,i) => {
      const isLast = i === historicalVolumes.length - 1;
      return {
        year:           Number(chartData[i].year),
        value:          v,
        // on the last historical point, duplicate value into both forecasts
        forecastLinear: isLast ? v : null,
        forecastScore:  isLast ? v : null,
      };
    });
    // 2) one object per forecast year, merging both
    const forecastSlice = scoreSettings.yearNames.map((yr, i) => ({
      year:            Number(yr),
      value:           null,
      forecastLinear:  forecastDataLR[i]?.forecastVolume  ?? null,
      forecastScore:   forecastDataScore[i]?.forecastVolume ?? null,
    }));
    return [...hist, ...forecastSlice];
  }, [
    chartData,
    historicalVolumes,
    forecastDataLR,
    forecastDataScore,
    scoreSettings.yearNames,
  ]);

  // 1) Build a map of name→node for quick lookups
  const nodeByName = useMemo(() => {
    const m = {};
    formatHierarchy.forEach(node => {
      m[node.name] = node;
    });
    return m;
  }, [formatHierarchy]);

  // 2) Build raw grouping from data keys → parent group name
  const regionsByGroup = useMemo(() => {
    const grouping = {};
    allRegions.forEach(regionName => {
      const node = nodeByName[regionName];
      if (!node) return;
      // find its immediate parent in the tree
      const parent = formatHierarchy.find(n => n.id === node.parent_id);
      const group = parent?.name || "Other";
      (grouping[group] = grouping[group] || []).push(node);
    });
    return grouping;
  }, [allRegions, nodeByName, formatHierarchy]);

  // 4) Initialize openGroups whenever `regionsByGroup` changes
  const [openGroups, setOpenGroups] = useState({});
  useEffect(() => {
    const init = {};
    Object.keys(regionsByGroup).forEach(g => init[g] = false);
    setOpenGroups(init);
  }, [regionsByGroup]);

  // 5) Helper for “select all” within a group
  const toggleGroupSelection = ( nodes) => {
    const allSelected = nodes.every(n => selectedRegions.includes(n.name));
    setSelectedRegions(curr =>
      allSelected
        ? curr.filter(r => !nodes.some(n => n.name === r))
        : [...curr, ...nodes.map(n => n.name).filter(nm => !curr.includes(nm))]
    );
  };

  console.log("chartdata ", chartData);

 const PALETTE = [
    // Sapphire Blue (your --accent)
    { light: '#15AFE4', dark:  '#0D7AAB' },
    // Amber Gold   (your --fg)
    { light: '#FFC107', dark:  '#B38600' },
    // Emerald Green (score forecast)
    { light: '#23DD1D', dark:  '#149A11' },
    // Teal Accent
    { light: '#38CCD4', dark:  '#1F7F84' },

    // Royal Purple
    { light: '#A17CFF', dark:  '#5E3DBD' },
    // Coral Sunset
    { light: '#FF8A65', dark:  '#C75B39' },
    // Mint Breeze
    { light: '#85FF8C', dark:  '#50AA5B' },
    // Rose Quartz
    { light: '#FF92E3', dark:  '#C25AA8' },
  ];

  const getColor = i => PALETTE[i % PALETTE.length].light;
  const getDark  = i => PALETTE[i % PALETTE.length].dark;


  // at top of your ForecastPage component, after you’ve computed selectedGraph:
  const legendPayload = useMemo(() => {
    const items = [
      { value: 'Historical',         type: 'line', color: '#D64444' }
    ];
    if (selectedGraph?.forecast_types?.includes('linear')) {
      items.push({
        value: 'Forecast (Stats)',
        type:  'line',
        color: '#F58C1F'
      });
    }
    if (selectedGraph?.forecast_types?.includes('score')) {
      items.push({
        value: 'Forecast (Survey-based)',
        type:  'line',
        color: '#23DD1D'
      });
    }
    return items;
  }, [selectedGraph]);

  // bar chart computations
  const barCount     = chartData.length;
  const maxBarSize   = barCount < 5 ? 100 : barCount < 10 ? 60 : 24;
  const barCategoryGap = barCount < 5 ? 40 : barCount < 10 ? 24 : 16;



  // old code-------------------------------------------------------------------------------------------
  // -------------------------------------------------------------------------------------------------------------
  
  // ——— State ———————————————————————————————————————————————————————————
  const [selectedChart, setSelectedChart] = useState("Bajaj's Auto's Operating Profit Margin (Rs.Cr)");
  const [chartType, setChartType]           = useState('bar');
  const [selectedCategories, setSelectedCategories] = useState([
    'Light CV',
    'Medium And Heavy CV',
    'Mopeds',
    'Motor Cycles',
  ]);
  const [isLogoHover, setLogoHover] = useState(false)
  const [isHovering, setIsHovering]         = useState(false);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [isDatasetHovering, setIsDatasetHovering] = useState(false);
  const [isRegionsHovering, setIsRegionsHovering] = useState(false);
  const [loading, setLoading] = useState(true);



  // ——— Handlers —————————————————————————————————————————————————————————
  const handleChartChange = (option) => {
    setSelectedChart(option.label);
    setChartType(option.chartType);
    setIsDropdownOpen(false);
    setIsHovering(false);
  };
  const toggleCategory = (category) => {
    setSelectedCategories(prev =>
      prev.includes(category)
        ? prev.filter(c => c !== category)
        : [...prev, category]
    );
  };

  // ——— Utilities & Data ——————————————————————————————————————————————
  const getColorForCategory = (category, enabled = true) => {
    const colors = {
      'Light CV': '#1039EE',
      'Medium And Heavy CV': '#23DD1D',
      Mopeds: '#38CCD4',
      'Motor Cycles': '#F58C1F',
    };
    return enabled ? colors[category] : '#ccc';
  };

  const allCategories = ['Light CV', 'Medium And Heavy CV', 'Mopeds', 'Motor Cycles'];
  const chartOptions = [
    { label: "Bajaj's Auto's Operating Profit Margin (Rs.Cr)", chartType: 'bar' },
    { label: 'Time Series', chartType: 'line' },
    { label: "Bajaj Auto's Sales Distribution", chartType: 'pie' },
  ];

  const bajajAutoData = [
    { year: '2013', 'Light CV': 50000, 'Medium And Heavy CV': 150000, Mopeds: 80000, 'Motor Cycles': 70000 },
    { year: '2014', 'Light CV': 60000, 'Medium And Heavy CV': 140000, Mopeds: 90000, 'Motor Cycles': 80000 },
    { year: '2015', 'Light CV': 55000, 'Medium And Heavy CV': 160000, Mopeds: 85000, 'Motor Cycles': 75000 },
    { year: '2016', 'Light CV': 70000, 'Medium And Heavy CV': 130000, Mopeds: 100000, 'Motor Cycles': 90000 },
    { year: '2017', 'Light CV': 50000, 'Medium And Heavy CV': 150000, Mopeds: 80000, 'Motor Cycles': 70000 },
    { year: '2018', 'Light CV': 60000, 'Medium And Heavy CV': 140000, Mopeds: 90000, 'Motor Cycles': 80000 },
    { year: '2019', 'Light CV': 55000, 'Medium And Heavy CV': 160000, Mopeds: 85000, 'Motor Cycles': 75000 },
    { year: '2020', 'Light CV': 70000, 'Medium And Heavy CV': 130000, Mopeds: 100000, 'Motor Cycles': 90000 },
    { year: '2021', 'Light CV': 50000, 'Medium And Heavy CV': 150000, Mopeds: 80000, 'Motor Cycles': 70000 },
    { year: '2022', 'Light CV': 60000, 'Medium And Heavy CV': 140000, Mopeds: 90000, 'Motor Cycles': 80000 },
    { year: '2023', 'Light CV': 55000, 'Medium And Heavy CV': 160000, Mopeds: 85000, 'Motor Cycles': 75000 },
    { year: '2024', 'Light CV': 70000, 'Medium And Heavy CV': 130000, Mopeds: 100000, 'Motor Cycles': 90000 },
  ];

  const CustomTooltip = ({ active, payload, label }) => {
    if (!active || !payload?.length) return null;
    return (
      <>
      <div className="tooltip-card">
        <p>{label}</p>
        {payload.map(p => (
          <div key={p.dataKey}>
            <span className="dot" style={{ background: p.color }}/> 
            {p.name}: {p.value}
          </div>
        ))}
      </div>
      <style jsx>{`
      .tooltip-card {
        background: rgba(20,20,20,0.9);
        padding: var(--space-sm);
        border-radius: var(--radius);
        box-shadow: var(--shadow-deep);
        color: rgba(255,255,255,0.7);
        font-size: 0.875rem;
      }
      .tooltip-card .dot {
        width:8px; height:8px; border-radius:50%;
        margin-right:4px; display:inline-block;
      }
      `}</style>
      </>
    );
  };


  // ——— Render —————————————————————————————————————————————————————————————
  return (
    <>
      {/* Desktop View */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -10 }}
        transition={{ duration: 0.4 }}
        className="de-view container-fluid"
        style={{ background: '#2C2E31' }}
      >
        <div className="container mt-1 ">  
        {/* ─── APP HEADER ───────────────────────────────────── */}
        <div className="app-header d-flex justify-content-between align-items-center">
         <Link href="/" passHref>
            <motion.div
                className="logo-container"
                onMouseEnter={() => setLogoHover(true)}
                onMouseLeave={() => setLogoHover(false)}
                onClick={() => router.push('/')}
                animate={{
                  scale: isLogoHover ? 1.05 : 1,
                  filter: isLogoHover
                    ? "drop-shadow(0 0 12px var(--accent, #FFDC00)) brightness(1.2) saturate(1.3)"
                    : "none"
                }}
                transition={{
                  scale: { type: "spring", stiffness: 300, damping: 20 },
                  filter: { duration: 0.2 }
                }}
              >
                <Image
                  src="/images/log.png"
                  alt="Race Auto India"
                  className="app-logo"
                  width={170}
                  height={60}
                />
                {/* <motion.span
                  className="logo-tooltip"
                  initial={{ opacity: 0, y: -8 }}
                  animate={isLogoHover ? { opacity: 1, y: 0 } : { opacity: 0, y: -8 }}
                  transition={{ delay: 0.3, duration: 0.2 }}
                >
                  <FaPlay style={{ marginRight: 4, color: '#fff', transform: 'rotate(-90deg)'}}/>
                  <span style={{textDecoration:'none'}}>Go Home</span>
                </motion.span> */}
              </motion.div>

          </Link>
          <div className="nav-buttons">
            <button
              className="nav-btn"
              onClick={() => router.push('/score-card')}
            >
              <FaClipboardList className="btn-icon" />
              Build Your Own Tailored Forecast
            </button>

            <button
              className="nav-btn"
              onClick={() => router.push('/reports')}
            >
              <FaBolt className="btn-icon" />
              Flash Reports
            </button>
          </div>

        </div>
          {/* Heading */}
          <h5 className="chart-header">
            <div
              className={`dropdown-toggle ${isHovering ? 'dropdown-open' : ''}`}
              onMouseEnter={() => setIsHovering(true)}
              onMouseLeave={() => setIsHovering(false)}
            >
              <span className="chart-title">
                {selectedGraph?.name || 'Select a graph'}
              </span>
              <div className={`chart-dropdown ${isHovering ? 'open' : ''}`}>
                {graphs.map((opt) => (
                  <div
                    key={opt.id}
                    onClick={() =>setSelectedGraphId(opt.id)}
                    className="mt-1"
                    style={{ cursor: 'pointer' }}
                  >
                    {opt.name}
                  </div>
                ))}
              </div>
            </div>
          </h5>
          {/* Dataset picker */}
          

          {/* Region filter, grouped by parent */}
          
          {/* Above your chart, in the same row: */}
          <div className="selectors d-flex align-items-center gap-3">
            <div
              className={`dropdown-toggle ${isDatasetHovering ? 'dropdown-open' : ''}`}
              onMouseEnter={() => setIsDatasetHovering(true)}
              onMouseLeave={() => setIsDatasetHovering(false)}
              onClick={() => setIsDatasetFilterOpen(o => !o)}
            >
              <span style={{ color:"white"}}>Datasets</span>
              <div className={`chart-dropdown ${isDatasetHovering ? 'open' : ''}`}>
                {selectedGraph?.dataset_ids.map(dsId => {
                const ds = volumeDataMap[dsId];
                if (!ds?.stream) return null;
                const parts = ds.stream.split(',').map(n => +n);
                const lastId = parts[parts.length - 1];
                const label = hierarchyMap[lastId] || `#${lastId}`;
                return (
                  <div
                    key={dsId}
                    onClick={() => setSelectedDatasetId(dsId)}
                    className="mt-1"
                    style={{ cursor: 'pointer', color: 'white' }}
                  >
                    {label}
                  </div>
                );
              })}
              </div>
            </div>

            <div
              className={`dropdown-toggle ${isRegionsHovering ? 'dropdown-open' : ''}`}
              onMouseEnter={() => setIsRegionsHovering(true)}
              onMouseLeave={() => setIsRegionsHovering(false)}
              onClick={() => setIsRegionFilterOpen(o => !o)}
            >
              <span style={{color:"white"}}>Regions</span>
              <div className={`chart-dropdown ${isRegionsHovering ? 'open' : ''}`}>
                {Object.entries(regionsByGroup).map(([groupName, nodes]) => {
                const allSelected = nodes.every(n => selectedRegions.includes(n.name));
                return (
                  <div key={groupName} style={{ marginBottom: 8, color: 'white' }}>
                    <label style={{ display: 'flex', alignItems: 'center', cursor: 'pointer' }}>
                      <input
                        type="checkbox"
                        className="me-2"
                        checked={allSelected}
                        onChange={() => toggleGroupSelection(nodes)}
                      />
                      <strong
                        onClick={e => {
                          e.preventDefault();
                          e.stopPropagation();
                          setOpenGroups(o => ({ ...o, [groupName]: !o[groupName] }));
                        }}
                        style={{ userSelect: 'none' }}
                      >
                        {groupName} {openGroups[groupName] ? '▾' : '▸'}
                      </strong>
                    </label>
                    {openGroups[groupName] && nodes.map(node => (
                      <label
                        key={node.id}
                        className="d-block ps-3"
                        style={{ fontSize: 14, marginTop: 4, color: 'white' }}
                      >
                        <input
                          type="checkbox"
                          className="me-2"
                          checked={selectedRegions.includes(node.name)}
                          onChange={() =>
                            setSelectedRegions(s =>
                              s.includes(node.name)
                                ? s.filter(x => x !== node.name)
                                : [...s, node.name]
                            )
                          }
                        />
                        {node.name}
                      </label>
                    ))}
                  </div>
                );
              })}
              </div>
            </div>
          </div>
          <div className="mt-3">
          {loading ? (
            // Skeleton placeholder
            <div className="skeleton-line" />
            ) : (!selectedGraph || !selectedDataset) ? (
              <p className="text-center">Please choose a graph & dataset.</p>
            ) : (
                <AnimatePresence mode="wait">
                  <motion.div
                    key={`${selectedGraphId}-${selectedDatasetId}`}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.5 }}
                  >
                <div className="chart-card">
                <ResponsiveContainer width="100%" height={400} style={{borderLeft:10}}>
                        {/* Line + linear and score forecast */}
                        {/*
                          Unified LineChart for all “line” cases.
                          We pick the data & forecast series based on forecast_types,
                          but keep all styling identical.
                        */}
                        {selectedGraph.chart_type === 'line' ? (() => {
                          const hasLinear = selectedGraph.forecast_types?.includes('linear');
                          const hasScore  = selectedGraph.forecast_types?.includes('score');

                          // pick the right dataset
                          const data = hasLinear && hasScore
                            ? bothData
                            : hasLinear
                              ? combinedData
                              : hasScore
                                ? combinedDataScore
                                : chartData;

                          return (
                            <LineChart
                              data={data}
                              margin={{ top: 20, right: 20, bottom: 20, left: 30 }}
                              animationDuration={2500}
                              animationEasing="ease-out"
                            >
                              <defs>
                                <linearGradient id="histGrad" x1="0" y1="0" x2="0" y2="1">
                                  <stop offset="0%" stopColor={hasLinear && hasScore ? '#D64444' : '#1039EE'} stopOpacity={0.9}/>
                                  <stop offset="100%" stopColor={hasLinear && hasScore ? '#D64444' : '#1039EE'} stopOpacity={0.3}/>
                                </linearGradient>
                              </defs>

                              {/* subtle grid */}
                              <CartesianGrid stroke="rgba(255,255,255,0.1)" strokeDasharray="3 3"/>

                              {/* styled axes */}
                              <XAxis
                                dataKey="year"
                                axisLine={false}
                                tickLine={false}
                                tick={{ fill: 'rgba(255,255,255,0.7)', fontSize: 12 }}
                              />
                              <YAxis
                                axisLine={false}
                                tickLine={false}
                                tick={{ fill: '#FFC107', fontSize: 12 }}
                                 /* start the axis at 95% of the min, end at 105% of the max */
                                domain={[
                                  dataMin => dataMin * 0.95,
                                  dataMax => dataMax * 1.05
                                ]}
                                /* Format every tick as an integer */
                                tickFormatter={v => Math.round(v)}
                                tickCount={5}
                                interval="preserveStartEnd"
                              />

                              {/* slim brush */}
                              <Brush
                                dataKey="year"
                                height={12}
                                stroke="rgba(255,255,255,0.4)"
                                fill="rgba(255,255,255,0.08)"
                                strokeWidth={1}
                                tickFormatter={d => d}
                                tick={{
                                  fill: 'rgba(255,255,255,0.6)',
                                  fontSize: 9,
                                  fontFamily: 'inherit',
                                }}
                                tickMargin={4}
                                traveller={
                                  <Rectangle
                                    width={6}
                                    height={16}
                                    radius={3}
                                    fill="rgba(255,255,255,0.6)"
                                    stroke="rgba(255,255,255,0.4)"
                                    strokeWidth={1}
                                    cursor="ew-resize"
                                  />
                                }
                              />

                              {/* custom tooltip & spaced legend */}
                              <Tooltip content={<CustomTooltip />} />
                              <Legend 
                              wrapperStyle={{ marginTop: 24 }}
                              payload={legendPayload}
                              />

                              {/* historical line always */}
                              <Line
                                dataKey="value"
                                name="Historical"
                                stroke="url(#histGrad)"
                                strokeWidth={3}
                                connectNulls
                                animationBegin={0}
                              />

                              {/* linear forecast, if any */}
                              {hasLinear && (
                                <Line
                                  dataKey={hasLinear && hasScore ? 'forecastLinear' : 'forecastVolume'}
                                  name="Forecast (Linear)"
                                  stroke="#F58C1F"
                                  strokeWidth={2}
                                  strokeDasharray="5 5"
                                  connectNulls
                                  animationBegin={150}
                                />
                              )}

                              {/* score forecast, if any */}
                              {hasScore && (
                                <Line
                                  dataKey={hasLinear && hasScore ? 'forecastScore' : 'forecastVolume'}
                                  name="Forecast (Score)"
                                  stroke="#23DD1D"
                                  strokeWidth={2}
                                  strokeDasharray="2 2"
                                  connectNulls
                                  animationBegin={300}
                                />
                              )}
                            </LineChart>
                          );
                     })() : selectedGraph.chart_type === 'bar' ? (
                          <BarChart
                            data={chartData}
                            margin={{ top: 20, right: 20, bottom: 20, left: 30 }}
                            barCategoryGap={barCategoryGap}
                            maxBarSize={maxBarSize}
                          >
                            {/* soft, low-contrast grid */}
                            <CartesianGrid stroke="rgba(255,255,255,0.05)" strokeDasharray="3 3"/>

                            <XAxis 
                              dataKey="year" axisLine={false} tickLine={false}
                              tick={{ fill: 'rgba(255,255,255,0.6)', fontSize: 12 }}
                              padding={{ left: 10, right: 10 }}
                            />
                            <YAxis 
                              axisLine={false} tickLine={false}
                              tick={{ fill: 'rgba(255,255,255,0.6)', fontSize: 12 }}
                            />

                            <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(255,255,255,0.08)' }}/>
                            <Legend wrapperStyle={{ color: 'rgba(255,255,255,0.7)', marginTop: 16 }} iconType="circle"/>

                            <defs>
                              {allRegions.filter(r=>selectedRegions.includes(r)).map((r,i) => (
                                <linearGradient key={r} id={`grad-${i}`} x1="0" y1="0" x2="0" y2="1">
                                  <stop offset="0%" stopColor={getColor(i)} stopOpacity={0.8}/>
                                  <stop offset="100%" stopColor={getDark(i)}  stopOpacity={0.3}/>
                                </linearGradient>
                              ))}
                            </defs>


                            {allRegions.filter(r=>selectedRegions.includes(r)).map((r,i) => (
                              <Bar
                                key={r}
                                dataKey={r}
                                stackId="a"
                                fill={`url(#grad-${i})`}
                                radius={[6,6,0,0]}            // pronounced rounding
                                className="premium-bar"
                              />
                            ))}
                          </BarChart>
                        ) : (
                           <PieChart>
                              {/* 1) Define per-slice gradients */}
                              <defs>
                                {pieData.map((_, i) => (
                                  <linearGradient key={i} id={`sliceGrad-${i}`} x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="0%" stopColor={getColor(i)} stopOpacity={0.8} />
                                    <stop offset="100%" stopColor={getDark(i)}  stopOpacity={0.3} />
                                  </linearGradient>
                                ))}
                              </defs>

                              {/* 2) Use a donut style, with paddingAngle for breathing room */}
                              <Pie
                                data={pieData}
                                dataKey="value"
                                nameKey="name"
                                cx="50%" cy="50%"
                                innerRadius={70}
                                outerRadius={110}
                                paddingAngle={4}
                                stroke="rgba(255,255,255,0.1)"
                                labelLine={false}
                                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                              >
                                {pieData.map((_, i) => (
                                  <Cell key={i} fill={`url(#sliceGrad-${i})`} />
                                ))}
                              </Pie>

                              {/* 3) Polished tooltip & legend */}
                              <Tooltip content={<CustomTooltip />} cursor={false} />
                              <Legend
                                verticalAlign="bottom"
                                align="center"
                                iconType="circle"
                                wrapperStyle={{ color: 'rgba(255,255,255,0.7)', marginTop: 16 }}
                              />
                            </PieChart>
                        )}
                      </ResponsiveContainer>
                      </div>
                      </motion.div>
                      </AnimatePresence>
                      )}
          </div>

        <Footer />
        </div>
      </motion.div>

      {/* Mobile View */}
      <div className="mo-view container-fluid">
        <div className="container mt-3">
          <h5 className="text-center position-relative">
            <div
              onMouseEnter={() => setIsHovering(true)}
              onMouseLeave={() => setIsHovering(false)}
              onClick={() => setIsDropdownOpen(o => !o)}
              style={{ display: 'inline-block', cursor: 'pointer', position: 'relative' }}
            >
              <span className="mt-5" style={{ color: 'white' }}>
                {selectedChart} ▼
              </span>
              <div className={`chart-dropdown ${isHovering || isDropdownOpen ? 'open' : ''}`}>
                {chartOptions.map((opt, i) => (
                  <div
                    key={i}
                    onClick={() => handleChartChange(opt)}
                    className="mt-1"
                    style={{ cursor: 'pointer' }}
                  >
                    {opt.label}
                  </div>
                ))}
              </div>
            </div>
          </h5>
          <ResponsiveContainer width="100%" height={400}>
            {chartType === 'line' ? (
              <LineChart data={bajajAutoData}>
                <XAxis dataKey="year" stroke="white" tick={{ fill: 'white' }} />
                <YAxis stroke="white" tick={{ fill: 'white' }} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#000', border: 'none' }}
                  labelStyle={{ color: 'white' }}
                  itemStyle={{ color: 'white' }}
                />
                <Legend />
                {allCategories.map(cat => (
                  <Line
                    key={cat}
                    dataKey={cat}
                    name={cat}
                    type="monotone"
                    stroke={getColorForCategory(cat, selectedCategories.includes(cat))}
                    strokeWidth={selectedCategories.includes(cat) ? 4 : 2}
                    dot={false}
                    strokeOpacity={selectedCategories.includes(cat) ? 1 : 0.3}
                    onClick={() => toggleCategory(cat)}
                  />
                ))}
              </LineChart>
            ) : chartType === 'bar' ? (
              <BarChart data={bajajAutoData}>
                <XAxis dataKey="year" stroke="white" tick={{ fill: 'white' }} />
                <YAxis stroke="white" tick={{ fill: 'white' }} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#000', border: 'none' }}
                  labelStyle={{ color: 'white' }}
                  itemStyle={{ color: 'white' }}
                />
                <Legend />
                {allCategories.map(cat => (
                  <Bar
                    key={cat}
                    dataKey={cat}
                    name={cat}
                    stackId="a"
                    fill={getColorForCategory(cat, selectedCategories.includes(cat))}
                    opacity={selectedCategories.includes(cat) ? 1 : 0.3}
                    onClick={() => toggleCategory(cat)}
                  />
                ))}
              </BarChart>
            ) : (
              <PieChart>
                <Pie
                  data={allCategories
                    .filter(cat => selectedCategories.includes(cat))
                    .map(cat => ({ name: cat, value: bajajAutoData.reduce((s, e) => s + e[cat], 0) }))}
                  cx="50%"
                  cy="50%"
                  outerRadius={120}
                  label={({ name, value }) => `${name}: ${value}`}
                  labelLine={false}
                >
                  {allCategories.map(cat => (
                    <Cell
                      key={cat}
                      name={cat}
                      fill={getColorForCategory(cat, selectedCategories.includes(cat))}
                      opacity={selectedCategories.includes(cat) ? 1 : 0.3}
                      onClick={() => toggleCategory(cat)}
                    />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ backgroundColor: '#000', border: 'none' }}
                  labelStyle={{ color: 'white' }}
                  itemStyle={{ color: 'white' }}
                />
                <Legend />
              </PieChart>
            )}
          </ResponsiveContainer>

          <p className="fw-light mt-5 text-white">Source: N/A</p>
          <div className="d-flex flex-column fw-light mt-2">
            <p className="text-white mb-2">
              © Copyright 2025 Race Auto India - All Rights Reserved.
            </p>
          </div>
          <div className="d-flex justify-content-between">
            <p className="text-white mb-0">Terms & Conditions</p>
            <p className="text-white mb-0">Privacy & Policy</p>
          </div>
        </div>
      </div>

      {/* Tab View */}
      <div className="ta-view container-fluid" style={{ marginTop: 150 }}>
        <div className="container mt-3">
          <h5 className="text-center position-relative">
            <div
              onMouseEnter={() => setIsHovering(true)}
              onMouseLeave={() => setIsHovering(false)}
              onClick={() => setIsDropdownOpen(o => !o)}
              style={{ display: 'inline-block', cursor: 'pointer', position: 'relative' }}
            >
              <span className="mt-5" style={{ color: 'white' }}>
                {selectedChart} ▼
              </span>
              <div className={`chart-dropdown ${isHovering || isDropdownOpen ? 'open' : ''}`}>
                {chartOptions.map((opt, i) => (
                  <div
                    key={i}
                    onClick={() => handleChartChange(opt)}
                    className="mt-1"
                    style={{ cursor: 'pointer' }}
                  >
                    {opt.label}
                  </div>
                ))}
              </div>
            </div>
          </h5>
          <div className="mt-5">
            <ResponsiveContainer width="100%" height={400}>
              {chartType === 'line' ? (
                <LineChart data={bajajAutoData}>
                  <XAxis dataKey="year" stroke="white" tick={{ fill: 'white' }} />
                  <YAxis stroke="white" tick={{ fill: 'white' }} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#000', border: 'none' }}
                    labelStyle={{ color: 'white' }}
                    itemStyle={{ color: 'white' }}
                  />
                  <Legend />
                  {allCategories.map(cat => (
                    <Line
                      key={cat}
                      dataKey={cat}
                      name={cat}
                      type="monotone"
                      stroke={getColorForCategory(cat, selectedCategories.includes(cat))}
                      strokeWidth={selectedCategories.includes(cat) ? 4 : 2}
                      dot={false}
                      strokeOpacity={selectedCategories.includes(cat) ? 1 : 0.3}
                      onClick={() => toggleCategory(cat)}
                    />
                  ))}
                </LineChart>
              ) : chartType === 'bar' ? (
                <BarChart data={bajajAutoData}>
                  <XAxis dataKey="year" stroke="white" tick={{ fill: 'white' }} />
                  <YAxis stroke="white" tick={{ fill: 'white' }} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#000', border: 'none' }}
                    labelStyle={{ color: 'white' }}
                    itemStyle={{ color: 'white' }}
                  />
                  <Legend />
                  {allCategories.map(cat => (
                    <Bar
                      key={cat}
                      dataKey={cat}
                      name={cat}
                      stackId="a"
                      fill={getColorForCategory(cat, selectedCategories.includes(cat))}
                      opacity={selectedCategories.includes(cat) ? 1 : 0.3}
                      onClick={() => toggleCategory(cat)}
                    />
                  ))}
                </BarChart>
              ) : (
                <PieChart>
                  <Pie
                    data={allCategories
                      .filter(cat => selectedCategories.includes(cat))
                      .map(cat => ({ name: cat, value: bajajAutoData.reduce((s, e) => s + e[cat], 0) }))}
                    cx="50%"
                    cy="50%"
                    outerRadius={120}
                    label={({ name, value }) => `${name}: ${value}`}
                    labelLine={false}
                  >
                    {allCategories.map(cat => (
                      <Cell
                        key={cat}
                        name={cat}
                        fill={getColorForCategory(cat, selectedCategories.includes(cat))}
                        opacity={selectedCategories.includes(cat) ? 1 : 0.3}
                        onClick={() => toggleCategory(cat)}
                      />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{ backgroundColor: '#000', border: 'none' }}
                    labelStyle={{ color: 'white' }}
                    itemStyle={{ color: 'white' }}
                  />
                  <Legend />
                </PieChart>
              )}
            </ResponsiveContainer>
          </div>
          <p className="fw-light mt-5 text-white">Source: N/A</p>
          <div className="d-flex flex-column fw-light mt-2">
            <p className="text-white mb-2">© Copyright 2025 Race Auto India - All Rights Reserved.</p>
          </div>
          <div className="d-flex justify-content-between">
            <p className="text-white mb-0">Terms & Conditions</p>
            <p className="text-white mb-0">Privacy & Policy</p>
          </div>
        </div>
      </div>

      {/* Shared dropdown CSS */}
      <style jsx>{`
        @keyframes shimmer {
          0%   { background-position: -200% 0; }
          100% { background-position: 200% 0; }
        }
        .skeleton-line {
          height: 350px;             /* same as your chart height */
          width: 100%;
          background: linear-gradient(
            90deg,
            var(--bg) 25%,
          rgba(58,60,63,1) 50%,
             var(--bg) 75%
          );
          background-size: 200% 100%;
          animation: shimmer 1.5s infinite;
          border-radius: var(--radius);
        } 
       .chart-dropdown {
          position: absolute;
          top: 100%;
          left: 0;
          width: auto;
          min-width: 140px;
          white-space: nowrap;
          transform: translateY(-15px) scale(0.95);
          opacity: 0;
          visibility: hidden;
          background: rgba(31,32,35,0.85);
          backdrop-filter: blur(4px);
          box-shadow:  0 8px 24px rgba(0,0,0,0.5);
          border: 1px solid rgba(255,255,255,0.1);
          border-radius: var(--radius);
          padding: var(--space-sm);
          transition: transform 200ms ease-out, opacity 200ms ease-out;
          z-index: 10;
          max-height: 400px;      /* whatever “max” you like */
          overflow-y: auto;       /* scroll when too tall */
          scrollbar-width: thin;  /* Firefox */
          scrollbar-color: rgba(255,255,255,0.2) transparent;
        }
        /* WebKit browsers */
        .chart-dropdown::-webkit-scrollbar {
          width: 6px;
        }
        .chart-dropdown::-webkit-scrollbar-track {
          background: rgba(255,255,255,0.05);
          border-radius: 3px;
        }
        .chart-dropdown::-webkit-scrollbar-thumb {
          background: rgba(255,255,255,0.2);
          border-radius: 3px;
        }
        .chart-dropdown::-webkit-scrollbar-thumb:hover {
          background: rgba(255,255,255,0.4);
        }
        .chart-dropdown.open {
          opacity: 1;
          visibility: visible;
          transform: translateY(0) scale(1);
        }
        .chart-dropdown div {
          display: block;
          padding: var(--space-sm, 8px) var(--space-md, 12px);
          margin-bottom: var(--space-xs, 4px);
          border-radius: var(--radius, 6px);
          user-select: none;
          cursor: pointer;
          transition: background 200ms ease, color 200ms ease;
          color: white;
        }
        .chart-dropdown div:last-child {
          margin-bottom: 0;
        }
        .chart-dropdown div:hover {
          background: rgba(21, 175, 228, 0.15);  /* light accent on hover */
          color: var(--accent, #15AFE4);
        }
        .chart-dropdown div.selected {
          background: rgba(21, 175, 228, 0.25);  /* stronger accent for selected */
          font-weight: 600;
        }

        .recharts-line-curve:hover { 
          transform: scale(1.03); 
          filter: drop-shadow(0 0 6px var(--accent, #15AFE4));
          transition: filter 150ms;
        }
        .recharts-bar-rectangle:hover {
          filter: drop-shadow(0 0 6px var(--accent, #15AFE4));
          transform: translateY(-2px);
          transition: all 150ms ease;
        }
        h5 { font-size: 1.25rem; font-weight: 600; }
        p  { font-size: 1rem; line-height: 1.5; }
        input[type="checkbox"] {
          appearance: none;
          width: 16px; height: 16px;
          border: 2px solid #FFC107;
          border-radius: 3px;
          position: relative;
          margin-right: 8px;
          transition: background 150ms;
        }
        input[type="checkbox"]:hover { 
          border-color: var(--accent); 
        }
        input[type="checkbox"]:checked {
          background: #FFC107;
        }
        input[type="checkbox"]::after {
          content: '';
          position: absolute;
          top: 2px; left: 5px;
          width: 4px; height: 8px;
          border: solid #2C2E31;
          border-width: 0 2px 2px 0;
          transform: rotate(45deg);
        }
        .dropdown-toggle {
          position: relative;
          display: inline-flex;
          align-items: center;
          gap: 4px;
          padding: 6px 10px;
          background: rgba(255,255,255,0.05);
          border-radius: 4px;
          cursor: pointer;
          transition: background 200ms ease;
          user-select: none;
        }
        .dropdown-toggle:hover {
          background: rgba(255,255,255,0.10);
        }
        /* Remove your old “content: '▼'” rules entirely and use this instead: */
        .dropdown-toggle::after {
          content: '';
          display: inline-block;
          width: 0;
          height: 0;
          margin-left: 8px;                           /* space between text & arrow */
          border-left: 8px solid transparent;
          border-right: 8px solid transparent;
          border-top: 8px solid var(--accent, #15AFE4);  /* your accent color */
          transition: transform 200ms ease, border-top-color 200ms ease;
        }

        .dropdown-toggle.dropdown-open::after {
          transform: rotate(180deg);                  /* flip it upside down */
          border-top-color: var(--accent-active, #FFDC00); /* optional highlight when open */
        }
        .recharts-line-curve:hover {
          filter: drop-shadow(0 0 6px var(--accent, #15AFE4));
          transition: filter 150ms;
        }
        .recharts-bar-rectangle:hover {
          filter: drop-shadow(0 0 6px var(--accent, #15AFE4));
          transition: filter 150ms;
        }
        .dropdown-toggle {
          display: flex;
          align-items: center;
          gap: 8px;
          background: rgba(255,255,255,0.05);
          border-radius: 4px;
          padding: 6px 10px;
          transition: background 200ms;
        }
        .dropdown-toggle:hover {
          background: rgba(255,255,255,0.1);
        }
        .dropdown-toggle svg {
          transition: transform 200ms;
        }
        .dropdown-open svg {
          transform: rotate(180deg);
        }
        .de-view {
          background: #2C2E31;
          background-image: radial-gradient(
            circle at top left,
            rgba(255,255,255,0.02),
            transparent
          );
        }
        .chart-header {
          display: flex;
          justify-content: center;
          align-items: center;
          margin-bottom: var(--space-md, 24px);
        }
        .chart-title {
          color: white;
          font-size: 1.25rem;
          line-height: 1;                     /* ensures perfect vertical centering */
        }
        .chart-card {
          background: var(--surface);
          border-radius: var(--radius);
          box-shadow: var(--shadow-soft);
          padding: var(--space-md);
          margin-bottom: var(--space-md);
        }
        .recharts-wrapper { margin-bottom: var(--space-md); }
        .recharts-legend-wrapper { margin-top: var(--space-md); }

        /* App header */
        .app-header {
          padding: var(--space-sm, 8px) 0;

        }
        .app-logo {
          height: 40px;
          user-select: none;
          border-radius: var(--radius);
          border: 2px solid transparent;
          transition: none; /* Framer will handle it */
        }
        .logo-container {
          position: relative;
          display: inline-block;
          cursor: pointer;
          text-decoration: none; /* no underlines on the link wrapper */
        }
        .logo-container:hover .app-logo {
          filter: drop-shadow(0 0 10px var(--accent-active, #FFDC00));
          transform: scale(1.05);
          filter: brightness(1.2) saturate(1.3);
          transition: filter 200ms ease;
        }
        .logo-tooltip {
          position: absolute;
          top: 100%;
          left: 50%;
          transform: translate(-50%, 8px);
          background: var(--accent-active);
          color: #fff;
          padding: 6px 10px;
          border-radius: 4px;
          font-size: 0.8125rem;
          font-weight: 500;
          pointer-events: none;
          white-space: nowrap;
          box-shadow: 0 2px 6px rgba(0,0,0,0.4);
          text-decoration: none;
        }
        .logo-tooltip::after {
          text-decoration: none;
          content: '';
          position: absolute;
          top: -6px;
          left: 50%;
          transform: translateX(-50%);
          border-left: 6px solid transparent;
          border-right: 6px solid transparent;
          border-bottom: 6px solid var(--accent-active);
        }
        .logo-container * {
          text-decoration: none !important;
        }

        .nav-buttons {
          display: flex;
          gap: var(--space-sm, 8px);
        }

        .nav-btn {
          display: inline-flex;
          align-items: center;
          gap: var(--space-xs, 6px);
          background: var(--surface);             /* dark, subtle resting state */
          color: var(--accent);                       /* your muted foreground */
          box-shadow: 0 2px 6px rgba(0,0,0,0.15);  /* light, low-contrast depth */
          border: none;
          padding: 8px 16px;
          border-radius: var(--radius);
          font-size: 0.875rem;
          font-weight: 500;
          transition:
            background 300ms ease-in-out,
            color      300ms ease-in-out,
            box-shadow 300ms ease-in-out,
            transform  200ms ease-in-out;
        }

        .nav-btn:hover {
          background: linear-gradient(135deg, var(--accent), var(--surface));
          color: #fff;
          box-shadow: 0 6px 16px rgba(0,0,0,0.3);
          transform: translateY(-2px);
        }

        .btn-icon {
          font-size: 1.1rem;
          /* subtle text-shadow for extra depth */
          text-shadow: 0 1px 2px rgba(0,0,0,0.3);
        }

      `}</style>
    {/* at bottom of your component */}
    <style jsx global>{`
      /* Dark panel */
      .recharts-brush .recharts-brush-background {
        fill: rgba(30,30,30,0.85) !important;
        stroke: none !important;
      }

      /* The selected window */
      .recharts-brush .recharts-brush-slide {
        fill: var(--accent, #15AFE4) !important;
        fill-opacity: 0.15 !important;
      }
      
      /* The little handles you drag */
      .recharts-brush .recharts-brush-traveller {
        fill: var(--accent, #15AFE4) !important;
        stroke: var(--fg, #FFC107) !important;
        stroke-width: 1 !important;
        cursor: ew-resize;
      }
      .recharts-brush .recharts-brush-traveller-end {
        fill: var(--accent, #15AFE4) !important;
        stroke: var(--fg, #FFC107) !important;
        stroke-width: 1 !important;
      }

      /* The year labels under the brush */
      .recharts-brush .recharts-brush-text {
        fill: var(--fg, #FFC107) !important;
        font-size: 0.75rem !important;
      }
      .chart-card {
        background: #1F2023;
        border-radius: 8px;
        padding: 16px;
        box-shadow: 0 4px 16px rgba(0,0,0,0.5);
      }
       /* give every bar a subtle shadow & smooth transition */
      .recharts-bar-rectangle {
        filter: drop-shadow(0 2px 4px rgba(0,0,0,0.25));
        transition: transform 200ms ease, filter 200ms ease;
      }
      /* hover: lift & brighten */
      .recharts-bar-rectangle:hover {
        transform: translateY(-4px);
        filter: drop-shadow(0 4px 8px rgba(0,0,0,0.35))
                drop-shadow(0 0 6px rgba(255,255,255,0.2));
      }
      /* make slices gently pop on hover */
      .recharts-pie-sector {
        /* ensure scale is applied from the pie's center, not the slice's own box */
        transform-box: fill-box;
        transform-origin: 50% 50%;
        transition: transform 200ms ease, filter 200ms ease;
      }
      .recharts-pie-sector:hover {
        transform: scale(1.05);
        /* a two-stage glow: inner softer pale accent, outer stronger active accent */
        filter:
          drop-shadow(0 0 4px rgba(255, 193, 7, 0.15))
          drop-shadow(0 0 8px rgba(255, 193, 7, 0.08));
      }

      /* tooltip already styled via CustomTooltip */

      /* legend icons a little bigger & spaced */
      .recharts-legend-item .recharts-legend-item-icon {
        width: 12px;
        height: 12px;
        margin-right: 6px;
      }
    `}</style>
    </>
  );
}
